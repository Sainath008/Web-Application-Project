﻿using Microsoft.AspNetCore.Mvc;
using TicketManagement;
using TicketMVC1.Models;

namespace TicketMVC1.Controllers
{
        public class TicketController : Controller
        {
            private readonly IRepo _repo;
            public List<TickDetails> Dauser { get; set; }
            public List<TickInfo1> Mvcuser = new List<TickInfo1>();
            public TicketController(IRepo repo)
            {
                _repo = repo;
            }
            [HttpGet]
            public IActionResult Index()
            {
                Dauser = _repo.GetAll();
                foreach (var item in Dauser)
                {
                    TickInfo1 ticket = new TickInfo1();
                    ticket.Id = item.Id;
                    ticket.Subject = item.Subject;
                    ticket.Priority = item.Priority;
                    ticket.Description = item.Description;
                    ticket.Deadline = item.Deadline;
                    ticket.SnapshotPath = item.SnapshotPath;
                    ticket.Status = item.Status;
                    ticket.CreatedBy = item.CreatedBy;
                    ticket.CreatedDate = item.CreatedDate;
                    Mvcuser.Add(ticket);
                }
                return View(Mvcuser);
            }
            [HttpGet]
            public IActionResult Add()
            {
                return View();
            }
            [HttpPost]
            public IActionResult Add(TickInfo1 ticket)
            {
                TickDetails details = new TickDetails();
                details.Id = ticket.Id;
                details.Subject = ticket.Subject;
                details.Priority = ticket.Priority;
                details.Description = ticket.Description;
                details.Deadline = ticket.Deadline;
                details.SnapshotPath = ticket.SnapshotPath;
                details.Status = ticket.Status;
                details.CreatedBy = ticket.CreatedBy;
                details.CreatedDate = ticket.CreatedDate;
                _repo.Add(details);
                return RedirectToAction("Index");




        }
        }

    }
